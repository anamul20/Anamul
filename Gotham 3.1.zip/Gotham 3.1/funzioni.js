class Guardie {
  
    constructor(nome, cognome, dataNascita ) {
        this.nome=nome;
        this.cognome=cognome;
        this.dataNascita=dataNascita;
    }

}

class Detenuti {

    constructor(nome, cognome, dataCarcerazione, dataScarcerazione, crimine) {
        this.nome = nome;
        this.cognome = cognome;
        this.dataCarcerazione=dataCarcerazione;
        this.dataScarcerazione=dataScarcerazione;
        this.crimine=crimine;
    }

}

var arrayGuardie=[];
var arrayDetenuti=[];



function inserisciGuardia(){
    
    var inputNome = document.getElementById('fname').value;
    var inputCognome = document.getElementById('lname').value;
    var inputData = document.getElementById('data').value;
    let guardie = new Guardie(inputNome, inputCognome, inputData);
    
   arrayGuardie.push(guardie);
  
   //verifica inserimento in array
    for (valore of arrayGuardie) {
       console.log(valore);
   }
   
 
   //inserisce in tabella
        var ultimoElemento = arrayGuardie.length;
        
        var txtVal = arrayGuardie[ultimoElemento-1].nome,
            listNode = document.getElementById('trGuardia'),
            liNode = document.createElement("td")
            txtNode = document.createTextNode(txtVal);

        liNode.appendChild(txtNode);
        listNode.append(liNode);


        var txtVal2 = arrayGuardie[ultimoElemento-1].cognome,
            listNode2 = document.getElementById('trGuardia'),
            liNode2 = document.createElement("td")
        txtNode2 = document.createTextNode(txtVal2);

        liNode2.appendChild(txtNode2);
        listNode2.append(liNode2);


        var txtVal3 = arrayGuardie[ultimoElemento-1].dataNascita,
            listNode3 = document.getElementById('trGuardia'),
            liNode3 = document.createElement("td")
        txtNode3 = document.createTextNode(txtVal3);

        liNode3.appendChild(txtNode3);
        listNode3.append(liNode3);
  
    //var JSONreadyUsers= JSON.stringify(arrayGuardie);
   // window.localStorage.setItem('guardia', JSONreadyUsers);
 // JSON.parse(localStorage['guardia']);

 // window.localStorage.setItem('guardia', JSON.stringify(arrayGuardie));
  //console.log(window.localStorage.getItem('guardia'));
   //JSON.parse(localStorage.guardie);
  
  
}




function inserisciDetenuto() {
    
    var inputNome = document.getElementById('nameDetenuto').value;
    var inputCognome = document.getElementById('lnameDetenuto').value;
    var inputDataArresto = document.getElementById('dataArresto').value;
    var inputDataRilascio = document.getElementById('dataRilascio').value;
    var inputCrimine = document.getElementById('crimine').value; 
    let detenuto = new Detenuti(inputNome, inputCognome, inputDataArresto, inputDataRilascio, inputCrimine );

    arrayDetenuti.push(detenuto);

    //verifica inserimento in array 
    


    //inserisce in tabella i criminali

    var ultimoElemento = arrayDetenuti.length;
    
    var txtVal = arrayDetenuti[ultimoElemento-1].nome,
        listNode = document.getElementById('trCriminale'),
        liNode = document.createElement("td")
        txtNode = document.createTextNode(txtVal);

    liNode.appendChild(txtNode);
    listNode.append(liNode);


    var txtVal2 = arrayDetenuti[ultimoElemento-1].cognome,
        listNode2 = document.getElementById('trCriminale'),
        liNode2 = document.createElement("td")
    txtNode2 = document.createTextNode(txtVal2);

    liNode2.appendChild(txtNode2);
    listNode2.append(liNode2);


    var txtVal3 = arrayDetenuti[ultimoElemento-1].dataCarcerazione,
        listNode3 = document.getElementById('trCriminale'),
        liNode3 = document.createElement("td")
    txtNode3 = document.createTextNode(txtVal3);

    liNode3.appendChild(txtNode3);
    listNode3.append(liNode3);

    var txtVal4 = arrayDetenuti[ultimoElemento-1].dataScarcerazione,
    listNode4 = document.getElementById('trCriminale'),
    liNode4 = document.createElement("td")
    txtNode4 = document.createTextNode(txtVal4);

    liNode4.appendChild(txtNode4);
    listNode4.append(liNode4);

    var txtVal5 = arrayDetenuti[ultimoElemento-1].crimine,
    listNode5 = document.getElementById('trCriminale'),
    liNode5 = document.createElement("td")
    txtNode5 = document.createTextNode(txtVal5);

    liNode5.appendChild(txtNode5);
    listNode5.append(liNode5);



    //window.localStorage.setItem('detenuto', JSON.stringify(arrayDetenuti));
   //console.log(window.localStorage.getItem('detenuto'));
    //JSON.parse(localStorage.detenuto)[1].nome
}  






function visualizzaGuardia() {
    

for (guardia in arrayGuardie) {

    var leggeNome = JSON.stringify(arrayGuardie[guardia].nome);
    localStorage.setItem('guardia', leggeNome);
    document.write(JSON.parse(localStorage['guardia']));

    
    var leggeCognome = JSON.stringify(arrayGuardie[guardia].cognome);
    localStorage.setItem('guardia', leggeCognome);
    document.write(JSON.parse(localStorage['guardia']));
    
    
    var leggeData = JSON.stringify(arrayGuardie[guardia].dataNascita);
    localStorage.setItem('guardia', leggeData);
    document.write(JSON.parse(localStorage['guardia']));
      
}

    //let riga = document.createElement('ul'); // <ul></ul>
    
    //riga.className = "rigaDetenuto";
    
    //this.appendChildren(riga,items); // <ul> <li></li></ul>
    //this.appendChildren(list,riga); // <div> <ul> <li> ...

}

