

class Guardie {
  
    constructor(nome, cognome, dataNascita ) {
        this.nome=nome;
        this.cognome=cognome;
        this.dataNascita=dataNascita;
    }

}


class Detenuti {

    constructor(nome, cognome, dataCarcerazione, dataScarcerazione, crimine) {
        this.nome = nome;
        this.cognome = cognome;
        this.dataCarcerazione=dataCarcerazione;
        this.dataScarcerazione=dataScarcerazione;
        this.crimine=crimine;
    }

}


var arrayGuardie=[];
var arrayDetenuti=[];



function inserisciGuardia(){
     
    
    var inputNome = document.getElementById('fname').value;
    var inputCognome = document.getElementById('lname').value;
    var inputData = document.getElementById('data').value;
    let guardie = new Guardie(inputNome, inputCognome, inputData);
    
   arrayGuardie.push(guardie);
  
    for (valore of arrayGuardie) {
       console.log(valore);
   }

}


function inserisciDetenuto() {

    var inputNome = document.getElementById('nameDetenuto').value;
    var inputCognome = document.getElementById('lnameDetenuto').value;
    var inputDataArresto = document.getElementById('dataArresto').value;
    var inputDataRilascio = document.getElementById('dataRilascio').value;
    var inputCrimine = document.getElementById('crimine').value; 
    let detenuto = new Detenuti(inputNome, inputCognome, inputDataArresto, inputDataRilascio, inputCrimine );

    arrayDetenuti.push(detenuto);

    for (valore of arrayDetenuti) {
        console.log(valore);
    }

}



